
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var gameState=PLAY;
var PLAY=1,END=0;
var obstacleGroup;
function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
 createCanvas(500, 500);

  
  monkey= createSprite(50,450,20,50);
 monkey.addAnimation("running",monkey_running);

  monkey.scale = 0.5;
  
  ground = createSprite(200,180,400,20);
 
  ground.x = ground.width /2;
  
 
 
 
  
  invisibleGround = createSprite(200,190,400,10);
  invisibleGround.visible = false;
  
  //create Obstacle and Cloud Groups
  obstaclesGroup = createGroup();
 
  
  monkey.setCollider("rectangle",0,0,monkey.width,monkey.height);
  monkey.debug = false
  
  score = 0;
  
}

function draw() {
  
  background(180);
  //displaying score
  text("Score: "+ score, 500,50);
  
  
  if(gameState === PLAY){

  
    
    ground.velocityX = -(4 + 3* score/100)
    //scoring
    score = score + Math.round(getFrameRate()/60);
  
        
    
    
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
    
    //jump when the space key is pressed
    if(keyDown("space")&& monkey.y >= 160) {
        monkey.velocityY = -12;
       
    }
    
    //add gravity
    monkey.velocityY = monkey.velocityY + 0.8
  
    //spawn the clouds
   
  
    //spawn obstacles on the ground

    
    if(obstaclesGroup.isTouching(monkey)){
        //trex.velocityY = -12;
      
        gameState = END;
      
      
    }
  
    if (gameState === END) {
     
     
     
     //change the trex animation
     
     
     
      ground.velocityX = 0;
      monkey.velocityY = 0
      
     
      //set lifetime of the game objects so that they are never destroyed
    obstaclesGroup.setLifetimeEach(-1);
    
     obstaclesGroup.setVelocityXEach(0);
   
}
  
 
  //stop trex from falling down
  monkey.collide(invisibleGround);
drawSprites();

  function createBanana(){
  if(frameCount%50===0){
     fruit=createSprite(600,Math.round(random(100,550)),10,10);
     fruit.velocityX=-4;
     fruit.lifetime=150;
  }
   
  function createObstacle(){
  if(frameCount%50===0){
     obstacle=createSprite(600,Math.round(random(100,550)),10,10);
     obstacle.velocityX=-4;
     obstacle.lifetime=-4
  }